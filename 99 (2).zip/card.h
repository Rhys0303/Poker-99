#ifndef CAERD_H
#define CARD_H

class  card
{
public:
	int value;
	card(int v);
	void print()const;
};
#endif